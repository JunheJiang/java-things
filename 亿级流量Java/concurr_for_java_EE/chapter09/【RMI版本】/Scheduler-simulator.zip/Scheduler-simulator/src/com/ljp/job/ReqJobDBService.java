package com.ljp.job;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ljp.bean.ReqJob;
import com.ljp.bean.ReqJobExecution;
import com.ljp.util.DBUtil;

public class ReqJobDBService {
	
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	
	public boolean addReqJob(ReqJob job) throws SQLException{
		Connection conn = DBUtil.getDBConnection();
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("insert into ins_req_job values('" + job.getId() + "','" + job.getBatch() + "','" + job.getReqCode() + "','" + job.getSolution() + "','" + dateFormat.format(job.getRuntime()) + "','" + job.getMessageBody() + "','" + job.getState() + "','" + job.getErrorInfo() + "','" + job.getApplication() + "')");
		
		stmt.close(); 
		conn.close();
		
		return true;
	}
	
	public boolean updateReqJobState(ReqJob job) throws SQLException{
		Connection conn = DBUtil.getDBConnection();
		Statement stmt = conn.createStatement(); 
		String sql = "update ins_req_job set state='" + job.getState() + "' where id='" + job.getId() + "'";
		System.out.println(sql);
		
		stmt.executeUpdate(sql);
		
		stmt.close(); 
		conn.close();
		
		return true;
	}
	
	public boolean addJobExecution(ReqJobExecution jobExecution) throws SQLException{
		Connection conn = DBUtil.getDBConnection();
		Statement stmt = conn.createStatement();
		String sql = "insert into ins_req_job_execution values('"+ jobExecution.getId() +"', '"+ jobExecution.getState() +"', '"+ dateFormat.format(jobExecution.getTimestamp()) +"', '"+ jobExecution.getReqJob() +"', '"+ jobExecution.getTrggerId() +"')";
		System.out.println(sql);
		stmt.executeUpdate(sql);
		
		stmt.close(); 
		conn.close();
		
		return true;
	}
	
	public String getReqJobIdByReqCodeAndBatch(String reqCode, String batch) throws SQLException{
		Connection conn = DBUtil.getDBConnection();
		Statement stmt = conn.createStatement();
		String sql = "select id from ins_req_job where req_code = '" + reqCode + "' and batch = '" + batch + "'";
		
		System.out.println(sql);
		ResultSet rs = stmt.executeQuery(sql);
		rs.next();
		String id = rs.getString("id");
		
		rs.close();
		stmt.close(); 
		conn.close();
		
		return id;
	}
	
	
	public List<ReqJob> getReqJobList(int firstIndex, int lastIndex) throws SQLException{
		Connection conn = DBUtil.getDBConnection();
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from ins_req_job limit " + firstIndex + ", " + lastIndex);
		
		List<ReqJob> listJobs = new ArrayList<ReqJob>();
		
		while(rs.next()){
			ReqJob tmpJob = new ReqJob();
			tmpJob.setId(rs.getString("id"));
			tmpJob.setBatch(rs.getString("batch"));
			tmpJob.setReqCode(rs.getString("req_code"));
			tmpJob.setSolution(rs.getString("solution"));
			tmpJob.setRuntime(new java.util.Date(rs.getDate("runtime").getTime() + rs.getTime("runtime").getTime() + 8 * 3600 * 1000 ));
			tmpJob.setMessageBody(rs.getString("message_body"));
			tmpJob.setErrorInfo(rs.getString("error_info"));
			tmpJob.setState(rs.getString("state"));
			tmpJob.setApplication(rs.getString("application"));
			
			listJobs.add(tmpJob);
		}
		
		
		rs.close();
		stmt.close(); 
		conn.close();
		return listJobs;
	}
	
	
//	public boolean updateJobExecution(){
//		return true;
//	}
	
}
