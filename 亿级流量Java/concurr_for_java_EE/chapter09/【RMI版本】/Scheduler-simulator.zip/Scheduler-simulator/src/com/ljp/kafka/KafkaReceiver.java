package com.ljp.kafka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.ljp.job.TmpSleepJob;
import com.ljp.listener.ReqJobStateListener;
import com.ljp.util.UUIDGenerator;

public class KafkaReceiver implements Runnable {

	@Override
	public void run() {
		
		Scheduler stdScheduler = null;
		try {
			stdScheduler = StdSchedulerFactory.getDefaultScheduler();
			stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
			stdScheduler.start();
		} catch (SchedulerException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
		while( true ){
			System.out.println("start read kafka!");
			File file = new File("E:\\kafka.txt");
	        BufferedReader reader = null;
	        try {
	            reader = new BufferedReader(new FileReader(file));
	            String tmpString = null;
	            int line = 1;

	            for( ; line<1000; line++){
	            	if ((tmpString = reader.readLine()) != null && tmpString.length() > 0) {
		            	String[] jobInfo = tmpString.split(",");

		        		JobDetail messagePlanJobDetail = JobBuilder.newJob(TmpSleepJob.class).withIdentity(jobInfo[0], jobInfo[1]).build();

		                Date date1 = new Date();
		            	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		            	

		            	//date1 = dateFormat.parse("2017-03-10 18:35:20");
		            	date1 = dateFormat.parse(jobInfo[2]);

		            	Trigger myTrigger = TriggerBuilder.newTrigger().withIdentity(UUIDGenerator.generate8UUID(), UUIDGenerator.generate8UUID()).startAt(date1).withSchedule(SimpleScheduleBuilder.simpleSchedule().withMisfireHandlingInstructionIgnoreMisfires().repeatSecondlyForTotalCount(1)).build();
		            	
		            	stdScheduler.scheduleJob(messagePlanJobDetail, myTrigger);
		            	
		            }
	            }
	            	
	            
	            
	            
	            reader.close();

	        } catch (IOException e) {
	            e.printStackTrace();
	        } catch (SchedulerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e1) {
	                }
	            }
	        }
	        
	        FileWriter fw = null;
			try {
				fw = new FileWriter(file);
			} catch (IOException e) {
				e.printStackTrace();
			}
			PrintWriter pw = new PrintWriter(fw);
			pw.println("");
			pw.flush();
			try {
				fw.flush();
				pw.close();
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			} 
	        
			System.out.println("end read kafka");
	        try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}
	
	public static void main(String[] args) throws ParseException{
		new KafkaReceiver().run();
	}

}
