package com.ljp.rmiservice;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;

import com.ljp.listener.ReqJobStateListener;

public class QuartzRMIFuncsImpl extends UnicastRemoteObject implements IQuartzRMIFuncs {
	
//	protected QuartzRMIFuncsImpl() throws RemoteException {
//		super();  
//	}

	public QuartzRMIFuncsImpl() throws RemoteException {
		super();
	}

	private static final long serialVersionUID = 4077329331699640333L;
	
	public boolean pauseJob(JobKey jobkey) throws SchedulerException{
		Scheduler stdScheduler =  StdSchedulerFactory.getDefaultScheduler();
		//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
		
		try{
			stdScheduler.pauseJob(jobkey);
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	
	public boolean resumeJob(JobKey jobKey) throws SchedulerException{
		Scheduler stdScheduler =  StdSchedulerFactory.getDefaultScheduler();
		//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());

		try{
			stdScheduler.resumeJob(jobKey);
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	public boolean deleteJob(JobKey jobKey) throws SchedulerException{
		Scheduler stdScheduler =  StdSchedulerFactory.getDefaultScheduler();
		//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
		
		try{
			stdScheduler.deleteJob(jobKey);
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	public boolean runJob(JobKey jobKey) throws SchedulerException{
		Scheduler stdScheduler =  StdSchedulerFactory.getDefaultScheduler();
		//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
		
		try{
			stdScheduler.triggerJob(jobKey);
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	public boolean pauseJob(String jobName, String jobGroup) {
		Scheduler stdScheduler = null;
		try {
			stdScheduler = StdSchedulerFactory.getDefaultScheduler();
			//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
			
		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{
			stdScheduler.pauseJob(new JobKey(jobName, jobGroup));
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	
	public boolean resumeJob(String jobName, String jobGroup){
		Scheduler stdScheduler = null;
		try {
			stdScheduler = StdSchedulerFactory.getDefaultScheduler();
			//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
			
		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{
			stdScheduler.resumeJob(new JobKey(jobName, jobGroup));
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	public boolean deleteJob(String jobName, String jobGroup){
		Scheduler stdScheduler = null;
		try {
			stdScheduler = StdSchedulerFactory.getDefaultScheduler();
		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{
			stdScheduler.deleteJob(new JobKey(jobName, jobGroup));
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	public boolean runJob(String jobName, String jobGroup){
		Scheduler stdScheduler = null;
		try {
			stdScheduler = StdSchedulerFactory.getDefaultScheduler();
			//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
			
		} catch (SchedulerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try{
			stdScheduler.triggerJob(new JobKey(jobName, jobGroup));
		}catch(Exception e){
			//log ......
			return false;
		}
		return true;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	public List<QuartzSimpleJobInfo> AllJobsInfo(){
		Scheduler stdScheduler = null;
		try {
			stdScheduler = StdSchedulerFactory.getDefaultScheduler();
			//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
			
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<QuartzSimpleJobInfo> jobs = new ArrayList<QuartzSimpleJobInfo>();
		
		try {
			for (String groupName : stdScheduler.getJobGroupNames()) { 
				for (JobKey jobKey : stdScheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName))) {
					String jobName = jobKey.getName();
					String jobGroup = jobKey.getGroup();
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					
					JobDetail jobTMP = stdScheduler.getJobDetail(jobKey);
			 
					//get job's trigger
					
					@SuppressWarnings("unchecked")
					List<Trigger> triggers = (List<Trigger>) stdScheduler.getTriggersOfJob(jobKey);
					
					for(Trigger tmpTrigger : triggers){
						Date startTime = tmpTrigger.getStartTime();

						QuartzSimpleJobInfo jobInfo = new QuartzSimpleJobInfo();
						jobInfo.setJobGroup(jobGroup);
						jobInfo.setJobName(jobName);
						jobInfo.setState(stdScheduler.getTriggerState(tmpTrigger.getKey()).toString());
						jobInfo.setRuntime(dateFormat.format(startTime));
						
						jobs.add(jobInfo);
					}
				}

			}
		} catch (SchedulerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return jobs;
	}
	
	
	public boolean startRMIBinding() throws RemoteException, MalformedURLException, AlreadyBoundException{
		System.out.print("Run...");

        QuartzRMIFuncsImpl quartzFuncs = new QuartzRMIFuncsImpl();
        
        //创建RMI注册中心
        LocateRegistry.createRegistry(11056);
        //RMI默认是1099端口。但如果冲突，可以采用其他端口。
        Naming.bind("rmi://127.0.0.1:11056/quartzFuncs", quartzFuncs);
        
        System.out.print("Ready......");
		
		return true;
	}
	
	public static void main(String[] args) throws SchedulerException{
		Scheduler stdScheduler =  StdSchedulerFactory.getDefaultScheduler();
		//stdScheduler.getListenerManager().addSchedulerListener(new ReqJobStateListener());
		
		
		stdScheduler.start();
		
		stdScheduler.pauseJob(new JobKey("9bI8MXXv", "jD6fimpq"));
//		stdScheduler.resumeJob(new JobKey("CEjIvGSV", "u1oY8bEo"));
//		stdScheduler.triggerJob(new JobKey("d1b63f80-6698-4fb7-9674-5c0bb82f1831", "group1"));
//		stdScheduler.deleteJob(new JobKey("d1b63f80-6698-4fb7-9674-5c0bb82f1831", "group1"));
		
	}
	
}
