package com.ljp.service;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;

import com.ljp.kafka.KafkaReceiver;
import com.ljp.rmiservice.QuartzRMIFuncsImpl;

public class Start {
	public static void main(String[] args) throws RemoteException, MalformedURLException, AlreadyBoundException{
		QuartzRMIFuncsImpl quartzRMIServer = new QuartzRMIFuncsImpl();
		quartzRMIServer.startRMIBinding();
		
		KafkaReceiver kafkaReceiver = new KafkaReceiver();
		new Thread(kafkaReceiver).start();
		
	}
}
