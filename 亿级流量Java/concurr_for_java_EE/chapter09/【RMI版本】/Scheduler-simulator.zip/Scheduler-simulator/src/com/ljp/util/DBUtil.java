package com.ljp.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	public static Connection getDBConnection(){
		Connection conn = null;
		String url = "";
		
		String driverClassName = null;
		String user = null;
		String password = null;


		//用于本地数据库连接2
		url = "jdbc:mysql://localhost:3306/request_job?useUnicode=true&characterEncoding=UTF-8";
		driverClassName="com.mysql.jdbc.Driver";
		user="root";
		password="ljp111";
		

		
		try {
			Class.forName(driverClassName).newInstance();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			Class.forName(driverClassName);//指定连接类型
			conn = DriverManager.getConnection(url, user, password);//获取连接
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return conn;
	}
	
}