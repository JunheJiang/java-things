package com.ljp.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

public class HttpClientUtil {
	public static String server_addr = "http://localhost:8080/Server-api-simulator";
	public static boolean notifyServerJobStateChanged(String jobName, String jobGroup, String state, String triggerIds){
    	
    	CloseableHttpClient httpclient = HttpClients.createDefault();   
        HttpPost httpPost = new HttpPost(server_addr + "/UpdateReqJobStateSvlt"); 
        System.out.println(server_addr + "/UpdateReqJobStateSvlt");
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();  
        nvps.add(new BasicNameValuePair("jobName", jobName));  
        nvps.add(new BasicNameValuePair("jobGroup", jobGroup)); 
        nvps.add(new BasicNameValuePair("state", state));
        nvps.add(new BasicNameValuePair("triggerIds", ""));
        
        try {
			httpPost.setEntity(new UrlEncodedFormEntity(nvps));
			httpclient.execute(httpPost);  
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
        
    	return true;
    }
	
	
	public static void main(String[] args){
		notifyServerJobStateChanged("AAA", "BBB", "WAITING", "");
	}
}
