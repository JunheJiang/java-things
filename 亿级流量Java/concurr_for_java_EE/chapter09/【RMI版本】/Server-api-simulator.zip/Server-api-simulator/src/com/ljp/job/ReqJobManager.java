package com.ljp.job;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.ljp.bean.ReqJob;
import com.ljp.bean.ReqJobExecution;

public class ReqJobManager {
	ReqJobDBService jobService = new ReqJobDBService();
	
	public boolean acceptedReqJob(ReqJob job, ReqJobExecution jobExecution) throws SQLException{
		jobService.addReqJob(job);
		jobService.addJobExecution(jobExecution);
		return true;
	}
	
	
	
	public boolean markJobStateChanged(String state, String jobName, String jobGroup, List<String> triggerIds) throws SQLException{
		ReqJob job = new ReqJob();
		
		
		String reqJobId = jobService.getReqJobIdByReqCodeAndBatch(jobName, jobGroup);
		
		job.setId(reqJobId);
		job.setState(state);
		jobService.updateReqJobState(job);
		
		
		Date now = new Date();
		
		if( triggerIds == null ){
			
			ReqJobExecution jobExecution = new ReqJobExecution();
			jobExecution.setId(UUID.randomUUID().toString().replace("-", ""));
			jobExecution.setReqJob(reqJobId);
			jobExecution.setState(state);
			jobExecution.setTimestamp(now);
			
			jobService.addJobExecution(jobExecution);
		}else{
			for(String tmpId : triggerIds){
				ReqJobExecution jobExecution = new ReqJobExecution();
				jobExecution.setId(UUID.randomUUID().toString().replace("-", ""));
				jobExecution.setReqJob(reqJobId);
				jobExecution.setState(state);
				jobExecution.setTrggerId(tmpId);
				jobExecution.setTimestamp(now);
				
				jobService.addJobExecution(jobExecution);
			}
		}
		

		return true;
	}
	
	public boolean pushReqJobToKafka(ReqJob job){
		//这里以kafka.txt替代真实的kafka-MQ
		
		FileWriter fw = null;
		try {
			File f=new File("E:\\kafka.txt");
			fw = new FileWriter(f, true);
		} catch (IOException e) {
			e.printStackTrace();
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		PrintWriter pw = new PrintWriter(fw);
		pw.println(job.getReqCode() + "," + job.getBatch() + "," + dateFormat.format(job.getRuntime()));
		pw.flush();
		try {
			fw.flush();
			pw.close();
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return true;
	}
	
	
	public List<ReqJob> getAllReqJobs() throws SQLException{
		List<ReqJob> listJobs = new ArrayList<ReqJob>();
		listJobs = jobService.getReqJobList(0, 999999);
		return listJobs;
	}
	
	
	
	
	
}
