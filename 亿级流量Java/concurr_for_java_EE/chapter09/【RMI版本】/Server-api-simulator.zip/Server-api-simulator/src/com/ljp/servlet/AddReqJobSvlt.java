package com.ljp.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ljp.bean.ReqJob;
import com.ljp.bean.ReqJobExecution;
import com.ljp.job.ReqJobManager;
import com.ljp.util.UUIDGenerator;

/**
 * Servlet implementation class AddReqJobSvlt
 */
@WebServlet("/AddReqJobSvlt")
public class AddReqJobSvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddReqJobSvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ReqJobManager jobManager = new ReqJobManager();
		ReqJob job = new ReqJob();
		ReqJobExecution jobExecution = new ReqJobExecution();
		
		String jobId = UUID.randomUUID().toString().replace("-", "");
		
		job.setId(jobId);
		job.setBatch(UUIDGenerator.generate8UUID());
		job.setReqCode(UUIDGenerator.generate8UUID());
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		try {
			date = dateFormat.parse("2017-03-15 18:57:23");
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		job.setRuntime(date);
		job.setSolution(UUID.randomUUID().toString().replace("-", ""));
		job.setMessageBody("......mesage body:......title...content...reminding...");
		job.setErrorInfo("");
		job.setState("QUEUE");
		job.setApplication(UUID.randomUUID().toString().replace("-", ""));
		
		
		jobExecution.setId(UUID.randomUUID().toString().replace("-", ""));
		jobExecution.setReqJob(jobId);
		jobExecution.setState(job.getState());
		jobExecution.setTimestamp(new Date());
		jobExecution.setTrggerId("");
		
		
		try {
			jobManager.pushReqJobToKafka(job);
			jobManager.acceptedReqJob(job, jobExecution);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	


}
