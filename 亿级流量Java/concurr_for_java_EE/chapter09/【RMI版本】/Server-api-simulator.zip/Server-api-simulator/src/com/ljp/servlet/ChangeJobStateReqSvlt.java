package com.ljp.servlet;

import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ljp.rmiservice.IQuartzRMIFuncs;

/**
 * Servlet implementation class ChangeJobStateSvlt
 * 该servlet用于接收前端更改job状态请求，通过RMI调用Quartz更改job状态
 */
@WebServlet("/ChangeJobStateReqSvlt")
public class ChangeJobStateReqSvlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeJobStateReqSvlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String reqState = request.getParameter("reqState");
		String jobName = request.getParameter("jobName");
		String jobGroup = request.getParameter("jobGroup");
		
		System.out.println(jobName);
		
		IQuartzRMIFuncs quartzFunctions = null;
		boolean successFlag = false;
		
		try {
			quartzFunctions = (IQuartzRMIFuncs) Naming.lookup("rmi://127.0.0.1:11056/quartzFuncs");
			
			if( (reqState != null) && (reqState.length() > 0) ){
				switch (reqState) {  
	            	case "PAUSE":  
	            		quartzFunctions.pauseJob(jobName, jobGroup);
	            		successFlag = true;
	            		break;  
	            	case "RESUME":  
	            		quartzFunctions.resumeJob(jobName, jobGroup);
	            		successFlag = true;
	            		break;  
	            	case "RUN":  
	            		quartzFunctions.runJob(jobName, jobGroup);
	            		successFlag = true;
	            		break;  
	            	case "DELETE":  
	            		quartzFunctions.deleteJob(jobName, jobGroup);
	            		successFlag = true;
	            		break;  
	            	default:  
	            		break;  
	            } 	
			}
		
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
		
		response.getWriter().println("{\"code\":\"" + successFlag + "\"}");
	}

}
